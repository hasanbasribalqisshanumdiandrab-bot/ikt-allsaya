# Area Hasan — Dashboard Web (2025 vs 2026)

Versi web dari aplikasi Android **Area Hasan** (Kotlin/Jetpack Compose).
Dibangun murni dengan HTML/CSS/JS (tanpa build step), sehingga bisa langsung
di-deploy lewat **GitHub Pages**.

Tampilan, warna, dan alur data direplikasi persis dari aplikasi asli:
- Header navy dengan banner, badge "LIVE DASHBOARD AREA HASAN"
- 3 tab: **📉 Sales 25 vs 26**, **🧑‍🤝‍🧑 KPI Personil**, **🎯 IKT Bauran**
- Data awal 18 toko Area Hasan Basri (sales, KPI personil, IKT) sama seperti di app
- Dialog **Tambah Toko** dan **Konfigurasi Google Sheets**

## Struktur file

```
index.html    → markup halaman
style.css     → tema warna & layout (identik dengan tema Material3 di app)
script.js     → data awal + logika (mirror dari ViewModel/Repository Kotlin)
assets/       → banner.jpg & icon.jpg (aset asli dari app)
```

## 🔗 Sinkron 3 Link Google Sheets

Sama seperti di aplikasi Android, dashboard ini punya **3 link Google Sheets**
yang bisa diatur lewat ikon *cloud-sync* di header (dialog "Konfigurasi Google
Sheets Real-Time"):

1. **Link Sales & Stok** — data penjualan (dipakai untuk sinkron real-time)
2. **Link KPI Personil**
3. **Link IKT 2026**

Nilai default-nya sama persis dengan yang ada di kode Android (`InitialDataProvider.kt`).
Saat klik **"Simpan & Sync Now"**, web app akan fetch data dari link **Sales & Stok**
dalam format CSV (`.../export?format=csv&gid=...`), lalu parsing kolom
`KODE_TOKO / NAMA / PLU / DESCP / QTY / NET_SALES` — persis seperti fungsi
`GoogleSheetsFetcher.kt` di app Android.

> **Catatan penting soal CORS:** karena ini berjalan di browser (bukan di
> device Android), sheet harus dibagikan sebagai **"Anyone with the link"**
> agar endpoint `export?format=csv` bisa diakses lintas origin. Jika sync
> gagal karena CORS/network, dashboard otomatis tetap memakai data cache
> (localStorage) — sama seperti perilaku *fallback* di app aslinya.

## 🚀 Cara deploy ke GitHub Pages

1. Buat repository baru di GitHub, misal `area-hasan-web`.
2. Upload semua file di folder ini (`index.html`, `style.css`, `script.js`,
   folder `assets/`) ke root repository tersebut (bisa lewat web upload atau git):
   ```bash
   git init
   git add .
   git commit -m "Area Hasan dashboard web"
   git branch -M main
   git remote add origin https://github.com/USERNAME/area-hasan-web.git
   git push -u origin main
   ```
3. Di repo GitHub → **Settings → Pages**.
4. Pada **Source**, pilih branch `main` dan folder `/ (root)`, lalu **Save**.
5. Tunggu 1–2 menit, link akan aktif di:
   ```
   https://USERNAME.github.io/area-hasan-web/
   ```

Tidak perlu build tool, npm, atau server — semua murni file statis.

## Penyimpanan data

Data (toko, sales, KPI, IKT, dan 3 link sheet) disimpan di **localStorage**
browser pengguna (menggantikan Room Database di Android). Artinya data
tersimpan per-browser/per-device — cocok untuk demo/monitoring pribadi.
Tombol **"Reset Standar"** di dialog konfigurasi akan mengembalikan semua
data ke nilai awal Area Hasan Basri.
